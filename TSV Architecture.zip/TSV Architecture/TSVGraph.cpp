#include "TSVGraph.h"

TSVNode::TSVNode(bool ftsv, bool rtsv, bool utsv, int blockId, int groupId, TSVNode* target)
        : isFtsv(ftsv), isRtsv(rtsv), isUtsv(utsv), blockId(blockId), groupId(groupId), target(target)
{
    for (int i = 0; i < 3; ++i)
        next[i] = nullptr;
}
TSVGraph::TSVGraph(int numBlocks, int numGroups, const std::array<int, 3>& qvals)
        : blockCount(numBlocks), groupCount(numGroups),redundantTSVs(numGroups), mainTSVGrid(numBlocks, std::vector<TSVNode*>(numGroups, nullptr))
{
    initRtsvNodes(numGroups);
    initTsvNodes(numBlocks, numGroups);
    initNextPointers(numBlocks, numGroups, qvals);
}
TSVGraph::TSVGraph()
    : blockCount(4), groupCount(16), redundantTSVs(16), mainTSVGrid(4, std::vector<TSVNode*>(16, nullptr))
{
    initRtsvNodes(16);
    initTsvNodes(4, 16);
    initNextPointers(4, 16, {12,3,7});
}
TSVGraph::~TSVGraph()
{
    for (auto ptr : redundantTSVs)
        delete ptr;
    for (auto& blockVec : mainTSVGrid)
        for (auto ptr : blockVec)
            delete ptr;
}
void TSVGraph::printInfo() const
{
    for (int i = 0; i < mainTSVGrid.size(); ++i)
    {
        std::cout << "block" << i << std::endl;
        for (int j = 0; j < mainTSVGrid[i].size(); ++j)
        {
            const TSVNode* node = mainTSVGrid[i][j];
            std::cout << "  T(" << node->blockId << "," << node->groupId
                << ") |target RTSV " << (node->target ? node->target->groupId : -1);
            std::cout << " |next T";
            for (int k = 0; k < 3; ++k)
            {
                if (node->next[k])
                    std::cout << "(" << node->next[k]->blockId << "," << node->next[k]->groupId << ") ";
                else
                    std::cout << "null ";
            }
            std::cout << std::endl;
        }
        std::cout << std::endl;
    }
}
void TSVGraph::printGraph() const {
    const char* RED = "\033[31m";
    const char* BLUE = "\033[34m";
    const char* GREEN = "\033[32m";
    const char* RESET = "\033[0m";

    int used = 0;
    int ftsvCount = 0;
    int total = (blockCount + 1) * groupCount;

    for (int i = 0; i < mainTSVGrid.size(); ++i) {
        std::cout << i << "|";
        for (int j = 0; j < mainTSVGrid[i].size(); ++j) {
            const TSVNode* node = mainTSVGrid[i][j];
            if (node->isFtsv) {
                ftsvCount++;
                std::cout << RED << "X" << RESET;
            }
            else if (node->isUtsv) {
                used++;
                std::cout << BLUE << "U" << RESET;
            }
            else {
                std::cout << GREEN << "O" << RESET;
            }
        }
        std::cout << std::endl;
    }
    std::cout << "R|";
    for (int i = 0; i < redundantTSVs.size(); ++i) {
        const TSVNode* node = redundantTSVs[i];
        if (node->isFtsv) {
            ftsvCount++;
            std::cout << RED << "X" << RESET;
        }
        else if (node->isUtsv) {
            //ȡ��ע�� ͳ�ư���RTSV��ΪUTSV������
            //used++;
            std::cout << BLUE << "U" << RESET;
        }
        else {
            std::cout << GREEN << "O" << RESET;
        }
    }
    std::cout << std::endl;

    if (used != 0) {
        double coverage = total > 0 ? 100.0 * used / total : 0.0;
        std::cout << "ʹ�õ� UTSV ����: " << used << " / " << total
            << "��������: " << std::fixed
            << coverage << "%\n" << std::endl;
    }
    else {
        double coverage = total > 0 ? 100.0 * ftsvCount / total : 0.0;
        std::cout << "���ϵ� FTSV ����: " << ftsvCount << " / " << total
            << "��������: " << std::fixed
            << coverage << "%\n" << std::endl;
    }
    std::cout << std::endl;
}

void TSVGraph::assignRandomFaults(int faultCount)
{
	repairNodes.clear();
    auto ftsv_array = generateRandomArray(0, (blockCount+1) * groupCount - 1);
    for (int i = 0; i < faultCount; ++i) {
        int index = ftsv_array[i];
        int fblock = index / groupCount;
        int fgroup = index % groupCount;
        if (fblock == blockCount) fblock = -1;
        markAsFaultNode(fblock, fgroup);
    }
}
void TSVGraph::markAsFaultNode(int blockId, int groupId)
{
    if (blockId == -1) {
		redundantTSVs[groupId]->isFtsv = true;
    }
    else {
		mainTSVGrid[blockId][groupId]->isFtsv = true;
        repairNodes.push_back(mainTSVGrid[blockId][groupId]);
    }
}
float TSVGraph::evaluateRepairDifficulty(TSVNode* faultyNode)
{
    if (faultyNode == nullptr) return -1;

    std::queue<std::pair<TSVNode*, int>> q;  // <�ڵ�ָ��, �㼶>

    // ��ӳ�ʼ����
    if (faultyNode->target) q.push({ faultyNode->target, 0 });
    for (int i = 0; i < 3; ++i) {
        if (faultyNode->next[i]) q.push({ faultyNode->next[i], 0 });
    }

    int c[4] = { 0 }, d[4] = { 0 };

    std::unordered_set<TSVNode*> visited;

    while (!q.empty()) {
        auto [node, level] = q.front();
        q.pop();

        if (!node || visited.count(node)) continue;
        visited.insert(node);

        if (level > 3) continue;

        bool isRtsv = node->isRtsv;
        bool isUtsv = node->isUtsv || node->isFtsv;

        if (isRtsv && isUtsv) d[level]++;
        else if (isUtsv) c[level]++;

        if (!isRtsv) {
            if (node->target) q.push({ node->target, level + 1 });
            for (int i = 0; i < 3; ++i) {
                if (node->next[i]) q.push({ node->next[i], level + 1 });
            }
        }
    }

    // ��Ȩ���ۼ��Ѷ�ֵ
    const float weights[4] = { 12.25, 3.5, 1, 0 };
    float difficulty = 0;
    for (int i = 0; i < 4; ++i) {
        float fault_value = (2 * c[i] + d[i]);
        difficulty += fault_value * weights[i];
    }

    return difficulty;
}
bool TSVGraph::findRepairPathBFS(TSVNode* startNode, std::vector<TSVNode*>& path) {
    if (!startNode) return false;

    using Path = std::vector<TSVNode*>;
    std::queue<std::pair<TSVNode*, Path>> q; // �����б��浱ǰ�ڵ��·��
    std::unordered_set<TSVNode*> visited;

    q.push({ startNode, {startNode} });
    visited.insert(startNode);

    while (!q.empty()) {
        auto [node, curPath] = q.front();
        q.pop();

        if (curPath.size() > MAX_ROUTING_DEPTH) {

            continue;
        }

        TSVNode* target = node->target;
        if (!target) continue; // ��Ŀ������

        // ��ֹ������Ŀ��ڵ㲻�� FTSV �Ҳ��� UTSV���ҵ���Ч·��
        if (!target->isFtsv && !target->isUtsv) {
            curPath.push_back(target);
            path = std::move(curPath);
            return true;
        }

        // ��չnextָ��
        for (int i = 0; i < 3; ++i) {
            TSVNode* nextNode = node->next[i];
            if (!nextNode) continue;

            // ֻ������ FTSV �ҷ� UTSV����δ���ʽڵ�
            if (!nextNode->isFtsv && !nextNode->isUtsv && visited.count(nextNode) == 0) {
                visited.insert(nextNode);
                Path newPath = curPath;
                newPath.push_back(nextNode);
                q.push({ nextNode, std::move(newPath) });
            }
        }
    }
    return false; // δ�ҵ�����������·��
}
bool TSVGraph::repairWithPath(TSVNode* ftsvNode) {
    if (!ftsvNode) return false;

    std::vector<TSVNode*> path;
    if (!findRepairPathBFS(ftsvNode, path)) {
        return false;
    }

    for (TSVNode* node : path) {
        node->isUtsv = true;
        if (node->isRtsv) {
            break;
        }
    }

    return true;
}
bool TSVGraph::repairAllFaults() {
    if (repairNodes.empty()) return true;

    if (repairNodes.size() == 1) {
        return repairWithPath(repairNodes[0]);
    }

    while (!repairNodes.empty()) {
        std::vector<std::pair<int, TSVNode*>> difficulty_list;
        for (TSVNode* node : repairNodes) {
            int d = evaluateRepairDifficulty(node);
            difficulty_list.emplace_back(d, node);
        }

        std::sort(difficulty_list.rbegin(), difficulty_list.rend());

        TSVNode* target = difficulty_list.front().second;

        repairNodes.erase(std::remove(repairNodes.begin(), repairNodes.end(), target), repairNodes.end());

        if (!repairWithPath(target)) {
            return false;
        }
    }

    return true;
}

std::pair<int, int> TSVGraph::countReachableNodes(int maxDepth)
{
    if (mainTSVGrid.empty() || mainTSVGrid[0].empty()) {
        return { 0, 0 };
    }

    using NodePtr = TSVNode*;
    NodePtr start = mainTSVGrid[0][0];

    std::queue<std::pair<NodePtr, int>> q;
    std::unordered_set<NodePtr> visitedNodes;
    std::unordered_set<int> visitedGroups;

    q.push({ start, 0 });
    visitedNodes.insert(start);
    visitedGroups.insert(start->groupId);

    while (!q.empty()) {
        auto [node, depth] = q.front();
        q.pop();
        if (depth == maxDepth) continue;
        for (int i = 0; i < 3; ++i)
        {
            NodePtr nextNode = node->next[i];
            if (!nextNode || visitedNodes.count(nextNode)) continue;

            visitedNodes.insert(nextNode);
            visitedGroups.insert(nextNode->groupId);
            q.push({ nextNode, depth + 1 });
        }
    }
    return {
        static_cast<int>(visitedGroups.size()),
        static_cast<int>(visitedNodes.size())
    };
}
void TSVGraph::initRtsvNodes(int numGroups)
{
    for (int i = 0; i < numGroups; ++i)
        redundantTSVs[i] = new TSVNode(false, true, false, -1, i, nullptr);
}
void TSVGraph::initTsvNodes(int numBlocks, int numGroups)
{
    for (int i = 0; i < numBlocks; ++i)
        for (int j = 0; j < numGroups; ++j)
            mainTSVGrid[i][j] = new TSVNode(false, false, false, i, j, redundantTSVs[j]);
}
void TSVGraph::initNextPointers(int numBlocks, int numGroups, const std::array<int, 3>& qvals)
{
    for (int i = 0; i < numBlocks; ++i)
        for (int j = 0; j < numGroups; ++j)
            for (int k = 0; k < 3; ++k)
            {
                int ni = (i + k + 1) % numBlocks;
                int nj = (j + qvals[k]) % numGroups;
                mainTSVGrid[i][j]->next[k] = mainTSVGrid[ni][nj];
            }
}
std::vector<int> TSVGraph::generateRandomArray(const int min, const int max) {
    std::random_device rd; // ʹ������豸����������
    std::mt19937 rng(rd()); // ʹ�ø����ӳ�ʼ���������
    std::vector<int> indices(max - min + 1); // �����СΪ [min, max] ��Ԫ�ظ���
    iota(indices.begin(), indices.end(), min); // ���� [min, min+1, ..., max-1, max]
    std::shuffle(indices.begin(), indices.end(), rng); // ��������
    return indices; // ���ش��Һ����������
}
