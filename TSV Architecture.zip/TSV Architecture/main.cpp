#include "findQ.h"
#include "TSVGraph.h"
#include "timer.h"
#include <thread>
#include <mutex>

#define SIMULATION_TIMES   100000

void performance(int faultCount, std::array<int,5>& param) {
    const int batchCount = 8;      //ͬʱ�����߳�����
    std::vector<std::thread> threads;
    std::vector<int> batchSuccess(batchCount, 0);

    int batchSize = SIMULATION_TIMES / batchCount;
    int remainder = SIMULATION_TIMES % batchCount;
    for (int batch = 0; batch < batchCount; ++batch) {
        int start = batch * batchSize + std::min(batch, remainder);
        int end = start + batchSize + (batch < remainder ? 1 : 0);

        threads.emplace_back([batch, &batchSuccess, faultCount, &param, start, end]() {
            int localSuccess = 0;
            for (int i = start; i < end; ++i) {
                TSVGraph graph(param[0], param[1], {param[2], param[3], param[4]});
                graph.assignRandomFaults(faultCount);
                if (graph.repairAllFaults()) {
                    ++localSuccess;
                }
            }
            batchSuccess[batch] = localSuccess;
        });
    }
    for (auto& t : threads) {
        t.join();
    }

    int totalSuccess = 0;
    for (int s : batchSuccess) {
        totalSuccess += s;
    }
    std::cout << "  " << faultCount << "   |   "
                  << totalSuccess / (SIMULATION_TIMES / 100.f) << "%" << std::endl;
}

int main() {

    int blockCount = 4;
    int groupCount = 16;  //��������

    auto [size,q0,q1,q2] = findAllBestQvals(blockCount, groupCount,
    (groupCount < 10) ? 2 :(groupCount < 17) ? 3 :(groupCount < 26) ? 4 :(groupCount < 41) ? 5 :(groupCount < 58) ? 6 :(groupCount < 79) ? 7 :8);
    std::array<int, 5> param = {blockCount, groupCount, q0, q1, q2};

    std::cout << "������Ϣ��" << std::endl;
    std::cout << "  blockCount: " << param[0] << std::endl;
    std::cout << "  groupCount: " << param[1] << std::endl;
    std::cout << "  q0: " << param[2] << std::endl;
    std::cout << "  q1: " << param[3] << std::endl;
    std::cout << "  q2: " << param[4] << std::endl;
    std::cout << "ģ�������" << SIMULATION_TIMES<<std::endl;
    std::cout << "������ | �޸��ʣ�%��"<< std::endl;
    Timer timer;
    std::cout << "-------------------------"<< std::endl;
    for (int i = 1; i <= groupCount; ++i) {
            performance(i, param);
    }

    // int blockCount = 4;
    // int groupCount = 16;
    //
    // auto [size,q0,q1,q2] = findAllBestQvals(blockCount, groupCount,
    // (groupCount < 10) ? 2 :(groupCount < 17) ? 3 :(groupCount < 26) ? 4 :(groupCount < 41) ? 5 :(groupCount < 58) ? 6 :(groupCount < 79) ? 7 :8);
    // std::array<int, 5> param = {blockCount, groupCount, q0, q1, q2};
    // TSVGraph graph(param[0], param[1], {param[2], param[3], param[4]});
    // graph.printGraph();
    //
    // graph.assignRandomFaults(16);
    //
    // graph.printGraph();
    // graph.repairAllFaults();
    // graph.printGraph();

    return 0;
}