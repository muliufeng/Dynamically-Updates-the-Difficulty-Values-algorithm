#pragma once
#include <tuple>
#include <algorithm>
#include "timer.h"
#include "TSVGraph.h"
std::tuple<int,int,int,int> findAllBestQvals(int numBlocks, int numGroups, int maxDepth);
void fineAvgSuccessTime();
