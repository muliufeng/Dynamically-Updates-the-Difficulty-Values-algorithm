#pragma once
#include <iostream>
#include <chrono>
class Timer {
private:
    static inline int global_id_counter = 0;
    int instance_id;
    std::chrono::time_point<std::chrono::high_resolution_clock> start_point, end_point;
public:
    Timer();
    ~Timer();
    double GetTimerMs() const;
};
