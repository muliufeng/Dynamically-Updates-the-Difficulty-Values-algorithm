#include "findQ.h"
std::tuple<int,int,int,int> findAllBestQvals(int numBlocks, int numGroups, int maxDepth)
{
    int totalCombinations = 0;
    std::vector<std::tuple<int, int, int, int>> validQvals; // (q0, q1, q2, nodeCount)
    for (int q0 = 1; q0 < numGroups; ++q0)
    {
        for (int q1 = 1; q1 < numGroups; ++q1)
        {
            for (int q2 = 1; q2 < numGroups; ++q2)
            {
                if (q0 == q1 || q0 == q2 || q1 == q2)
                {
                    continue;
                }
                totalCombinations++;
                TSVGraph graph(numBlocks, numGroups, { q0, q1, q2 });
                auto [groupCount, nodeCount] = graph.countReachableNodes(maxDepth);

                if (groupCount == numGroups) {
                    validQvals.emplace_back(q0, q1, q2, nodeCount);
                }
            }
        }
    }

    if (validQvals.empty())
    {
        std::cout << "0" << std::endl;
        return std::make_tuple(0,0, 0, 0);
    }

    auto it = std::max_element(
        validQvals.begin(),
        validQvals.end(),
        [](const auto& a, const auto& b) {
            return std::get<3>(a) < std::get<3>(b);
        }
    );
    int maxNodeCount = std::get<3>(*it);
    std::vector<std::tuple<int, int, int, int>> bestQvals;
    std::copy_if(
        validQvals.begin(),
        validQvals.end(),
        std::back_inserter(bestQvals),
        [maxNodeCount](const auto& qval) {
            return std::get<3>(qval) == maxNodeCount;
        }
    );
    //double probability = static_cast<double>(bestQvals.size()) / totalCombinations;

    //std::cout << "Total valid qvals: " << validQvals.size() << std::endl;
    //std::cout << "Maximum nodeCount = " << maxNodeCount << std::endl;
    //std::cout << "Best qvals count = " << bestQvals.size() << std::endl;
    //std::cout << "probability = " << probability * 100 << " % \n";
   // for(auto& qval : bestQvals)
   // {
   //     std::cout << "q0 = " << std::get<0>(qval) << ", q1 = " << std::get<1>(qval)
   //               << ", q2 = " << std::get<2>(qval) << ", nodeCount = " << std::get<3>(qval) << std::endl;
   // }

    int q0 = std::get<0>(bestQvals[0]);
    int q1 = std::get<1>(bestQvals[0]);
    int q2 = std::get<2>(bestQvals[0]);
    int size = bestQvals.size();
    return std::make_tuple(size, q0, q1, q2);
}
void fineAvgSuccessTime()
{
    int deepth = 7;
    for (int i = 78; i <= 100; i++)
    {
        if (i == 10 || i == 17 || i == 26 || i == 41 || i == 58 || i == 79) {
            deepth++;
        }
        std::cout << "\n======" << "i = " << i << " deepth = " << deepth << "======" << std::endl;
        Timer timer;
        int successCount = std::get<0>(findAllBestQvals(4, i, deepth));
        double totalSearchTime = timer.GetTimerMs();
        std::cout << "avgSuccessTime = " << totalSearchTime / successCount << " ms" << std::endl;
    }
}