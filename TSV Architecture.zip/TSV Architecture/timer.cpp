#include "timer.h"
Timer::Timer() : instance_id(global_id_counter++)
{
    start_point = std::chrono::high_resolution_clock::now();
    std::cout << "Timer #" << instance_id << " started\n";
}
Timer::~Timer()
{
    end_point = std::chrono::high_resolution_clock::now();
    auto start = std::chrono::time_point_cast<std::chrono::microseconds>(start_point).time_since_epoch().count();
    auto end = std::chrono::time_point_cast<std::chrono::microseconds>(end_point).time_since_epoch().count();
    auto duration = end - start;
    double ms = duration * 0.001;
    std::cout << "Timer #" << instance_id << " ended: " << duration << " us (" << ms << " ms)" << std::endl;
}
double Timer::GetTimerMs() const
{
    auto end = std::chrono::high_resolution_clock::now();
    auto start = std::chrono::time_point_cast<std::chrono::microseconds>(start_point).time_since_epoch().count();
    auto end_time = std::chrono::time_point_cast<std::chrono::microseconds>(end).time_since_epoch().count();
    auto duration = end_time - start;
    return duration * 0.001;
}