#pragma once
#include <iostream>
#include <vector>
#include <cmath>
#include <queue>
#include <unordered_set>
#include <array>
#include <algorithm>
#include <random>
#include <numeric>

constexpr int MAX_ROUTING_DEPTH = 6;

struct TSVNode
{
    bool isFtsv;
    bool isRtsv;
    bool isUtsv;
    int blockId;
    int groupId;
    TSVNode* target;
    TSVNode* next[3];
    TSVNode(bool ftsv, bool rtsv, bool utsv, int blockId, int groupId, TSVNode* target);
};
class TSVGraph
{
public:
    TSVGraph(int numBlocks, int numGroups, const std::array<int, 3>& qvals);
    TSVGraph();
    ~TSVGraph();
    void printInfo() const;
    void printGraph() const;
    void assignRandomFaults(int faultCount);
    bool repairAllFaults();
    std::pair<int, int> countReachableNodes(int maxDepth);
private:
    int blockCount;
    int groupCount;
    std::vector<TSVNode*> redundantTSVs;
    std::vector<std::vector<TSVNode*>> mainTSVGrid;
    std::vector<TSVNode*> repairNodes;
    std::vector<int> generateRandomArray(const int min, const int max);
    float evaluateRepairDifficulty(TSVNode* faultyNode);
    bool findRepairPathBFS(TSVNode* startNode, std::vector<TSVNode*>& path);
    bool repairWithPath(TSVNode* ftsvNode);
    void markAsFaultNode(int blockId, int groupId);
    void initRtsvNodes(int numGroups);
    void initTsvNodes(int numBlocks, int numGroups);
    void initNextPointers(int numBlocks, int numGroups, const std::array<int, 3>& qvals);
};
